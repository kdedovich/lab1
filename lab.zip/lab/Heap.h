#pragma once
#include <stdexcept>
#include "Vector.h"
using std::logic_error;
template<class Key>
class THeap {
public:
	bool is_empty();
	void insert(Key key);
	Key extract_min();
	Key get_min();
	int size();
	void print();
	void optimaze(int Kinser, int Kextract);
	THeap();
	~THeap();
	template<typename Iterator>
	THeap(Iterator begin, Iterator end);
private:
	class TNode;
	int K = 2, HeapSize = 0;
	Vector<Key> element;
	void sift_up(int index);
	void sift_down(int index);
	void swap(int a, int b);
};

template <class Key>
THeap<Key>::THeap() {
	HeapSize = 0;
	element.resize(0);
	K = 2;
}

template <class Key>
THeap<Key>::~THeap() {}

template <class Key>
void THeap<Key>::sift_up(int index) {
	while ((index != 0) && (element[index] < element[(index - 1) / K])) {
		swap(index, (index - 1) / K);
		index = (index - 1) / K;
	}
}

template <class Key>
void THeap<Key>::sift_down(int index) {
	int minson = index;
	for (int i = 1; i <= K; i++) {
		if (K * index + i >= element.size())
			break;
		if (element[K * index + i] < element[minson])
			minson = index * K + i;
	}
	while ((minson != index) && (index < element.size()) && (element[minson] < element[index])) {
		swap(index, minson);
		index = minson;
		for (int i = 1; i <= K; i++) {
			if (K * index + i >= element.size())
				break;
			if (element[K * index + i] < element[minson])
				minson = index * K + i;
		}
	}
}

template <class Key>
void THeap<Key>::insert(Key a) {
	int index = HeapSize;
	element.push_back(a);
	sift_up(index);
	HeapSize++;
}


template <class Key>
Key THeap<Key>::extract_min() {
	//cout << "ky-ky";
	if (is_empty())
		throw logic_error("Heap is empty"); 
	Key ans = element[0];
	swap(0, HeapSize - 1);
	HeapSize--;
	element.pop_back();
	if (HeapSize != 0) {
		int index = 0;
		sift_down(index);
	}
	return ans;
}

template <class Key>
Key THeap<Key>::get_min() {
	if (is_empty())
		throw logic_error("Heap is empty");
	return element[0];
}

template <class Key>
int THeap<Key>::size() {
	return element.size();
}

template <class Key>
void THeap<Key>::print() {
	for (int i = 0; i < HeapSize; i++)
		std::cout << element[i] << " ";
	cout << "\n";
}


template<class Key>
bool THeap<Key>::is_empty() {
	return element.is_empty();
}

template<class Key>
template<class Iterator>
THeap<Key>::THeap(Iterator begin, Iterator end) {
	HeapSize = 0;
	for (Iterator it = begin; it != end; it++)
		element.push_back(*it), HeapSize++;

	for (int i = element.size() - 1; i >= 0; i--)
		sift_down(i);
}

template<class Key>
void THeap<Key>::optimaze(int Kinsert, int Kextract) {
	if (Kextract == 0)
		Kextract = 1;
	K = 2;
	if ((Kinsert / Kextract) > 2)
		K = Kinsert / Kextract;
}


template<typename Key>
void THeap<Key>::swap(int x, int y) {
	Key a = element[x];
	Key b = element[y];
	element[x] = b;
	element[y] = a;
}
