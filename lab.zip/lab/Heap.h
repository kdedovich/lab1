#pragma once
#include <stdexcept>
#include "Vector.h"
using std::logic_error;
template<class Key>
class THeap {
public:
	class TNode;
	class pointer;
	bool is_empty();
	void insert(Key key);
	Key extract_min();
	Key get_min();
	void optimaze(int insertCount, int extractCount);
	THeap() = default;
	template<typename Iterator>
	THeap(Iterator begin, Iterator end);
private:
	int K = 2;
	Vector<Key> element;
	void sift_up(int index);
	void sift_down(int index);
	void swap(Key& a, Key& b);
};

template<class Key>
void THeap<Key>::sift_up(int index) {
	while ((index != 0) && (element[index] < element[(index - 1) / K])) {
		swap(element[index], element[(index - 1) / K]);
		index = (index - 1) / K;
	}
}

template<class Key>
void THeap<Key>::sift_down(int index) {
	while (1) {
		int minSon = index;
		for (int son = K * index + 1; (son <= K * index + K) && (son < element.size()); ++son) {
			if (element[son] < element[minSon])
				minSon = son;
		}
		if (minSon == index)
			break;

		swap(element[index], element[minSon]);
		index = minSon;
	}
}



template<class Key>
void THeap<Key>::insert(Key key) {
	element.push_back(key);
	sift_up(element.size() - 1);
}

template<class Key>
Key THeap<Key>::get_min() {
	if (is_empty())
		throw logic_error("Heap is empty");
	return element[0];
}

template<class Key>
Key THeap<Key>::extract_min() {
	if (is_empty())
		throw logic_error("Heap is empty");
	Key ans = element[0];
	std::swap(element[0], element[element.size() - 1]);
	element.pop_back();
	sift_down(0);
	return ans;
}

template<class Key>
bool THeap<Key>::is_empty() {
	return element.is_empty();
}

template<class Key>
template<class Iterator>
THeap<Key>::THeap(Iterator begin, Iterator end) {
	for (Iterator it = begin; it != end; it++)
		element.push_back(*it);

	for (int i = element.size() - 1; i >= 0; i--)
		sift_down(i);
}

template<class Key>
void THeap<Key>::optimaze(int insertCount, int extractCount) {
	if (extractCount == 0)
		extractCount = 1;
	if ((insertCount / extractCount) > 2)
		K = insertCount / extractCount;
	else
		K = 2;
}


template<typename Key>
void THeap<Key>::swap(Key &x, Key &y) {
	Key tmp = x;
	x = y;
	y = tmp;
}
