//����� ��������, ��� ��� ������������
#include <vector>
#include<stdexcept>
#include <cmath>
#include <algorithm>
using std::logic_error;
using std::vector;

class TestHeap {
public:
	vector<int> element;
	TestHeap(vector<int> value);
	TestHeap();
	template<class Iterator>
	TestHeap(Iterator begin, Iterator end);
	void insert(int key);
	int extract_min();
	int get_min();
	bool is_empty();
	void merge(TestHeap& h);
};

TestHeap::TestHeap() : element(0) {}

TestHeap::TestHeap(vector<int> a) : element(a) {}

void TestHeap::insert(int key) {
	element.push_back(key);
}

bool TestHeap::is_empty() {
	return element.empty();
}

int TestHeap::extract_min() {
	int minElement = 0;
	for (int i = 0; i < (int)element.size(); i++) {
		if (element[minElement] > element[i])
			minElement = i;
	}
	int ans = element[minElement];
	std::swap(element[minElement], element[element.size() - 1]);
	element.pop_back();
	return ans;
}

int TestHeap::get_min() {
	int minElement = 0;
	for (int i = 0; i < (int)element.size(); i++) {
		if (element[minElement] > element[i])
			minElement = i;
	}
	return element[minElement];
}

void TestHeap::merge(TestHeap& h) {
	for (int i = 0; i < h.element.size(); i++)
		element.push_back(h.element[i]);
	h.element.clear();
}

template<class Iterator>
TestHeap::TestHeap(Iterator begin, Iterator end) {
	for (Iterator it = begin; it != end; it++)
		element.push_back(*it);
}