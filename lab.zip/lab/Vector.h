#pragma once
#include<stdexcept>
#include <cmath>
using std::logic_error;
using std::out_of_range;
template <class T>
class  Vector {
	int VectorSize = 0, VectorCapacity = 0;
	int Log = 0;
	T* buffer = nullptr;
public:
	Vector() = default;
	~Vector();
	Vector(int size);
	int capacity() const;
	int size() const;
	bool is_empty() const;
	void push_back(T value);
	void pop_back();
	void reserve(int capacity);
	void resize(int size);
	T & operator[](int index);
	Vector<T> & operator = (const Vector<T> &);
	void clear();
};

template<class T>
Vector<T>::Vector(int size) {
	VectorSize = size;
	Log = ceil(log((double)size) / log(2.0));
	VectorCapacity = 1 << Log;
	buffer = new T[VectorCapacity];
}

template <class T>
bool Vector<T>::is_empty() const {
	return VectorSize == 0;
}

template<class T>
Vector<T>& Vector<T>::operator = (const Vector<T> & v) {
	delete[] buffer;
	VectorSize = v.VectorSize;
	Log = v.Log;
	VectorCapacity = VectorCapacity;
	buffer = new T[VectorCapacity];
	for (unsigned int i = 0; i < VectorSize; i++)
		buffer[i] = v.buffer[i];
	return *this;
}

template<class T>
int Vector<T>::size() const {
	return VectorSize;
}

template<class T>
int Vector<T>::capacity()const {
	return VectorCapacity;
}

template<class T>
void Vector<T>::reserve(int capacity) {
	T* newBuffer = new T[capacity];

	for (unsigned int i = 0; i < VectorSize; i++)
		newBuffer[i] = buffer[i];

	VectorCapacity = capacity;
	if (size() != 0)
		delete[] buffer;
	buffer = newBuffer;
}

template<class T>
void Vector<T>::resize(int size) {
	if (size == 0)
		Log = 0;
	else
		Log = ceil(log((double)size) / log(2.0));
	VectorSize = min(size, VectorSize);
	reserve(1 << Log);
	VectorSize = size;
}

template<class T>
void Vector<T>::push_back(T value) {
	if (VectorSize + 1 >= VectorCapacity) {
		Log++;
		reserve(1 << Log);
	}
	buffer[VectorSize++] = value;
}

template<class T>
void Vector<T>::pop_back() {
	if (size() == 0)
		throw logic_error("Vector is Empty");

	VectorSize--;
	if (VectorSize <= VectorCapacity / 4) {
		Log--;
		VectorCapacity = 1 << Log;
		reserve(1 << Log);
	}
}

template<class T>
T& Vector<T>::operator[](int index) {
	if (0 > index || index >= size())
		throw out_of_range("Out of Range");
	return buffer[index];
}

template<class T>
Vector<T>::~Vector() {
	if (buffer != nullptr)
		delete[] buffer;
}

template <class T>
void Vector<T>::clear() {
	VectorCapacity = 0;
	VectorSize = 0;
	buffer = 0;
	Log = 0;
}
