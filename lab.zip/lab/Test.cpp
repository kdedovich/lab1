#define BOOST_TEST_MODULE mytests
#include <boost/test/included/unit_test.hpp>
#include "Vector.h"
#include <cmath>
#include <ctime>
#include "Heap.h"
#include "TestHeap.h"
#include "BinHeap.h"
using std::cout;
clock_t start, end;

BOOST_AUTO_TEST_SUITE(TestVector)
BOOST_AUTO_TEST_CASE(push_back) {
	Vector<int> a;
	int* ans = new int[1000];
	for (size_t i = 0; i < 1000; i++) {
		ans[i] = rand();
		a.push_back(ans[i]);
	}
	for (int i = 0; i < 1000; i++)
		BOOST_CHECK_EQUAL(ans[i], a[i]);
	delete[] ans;
}


BOOST_AUTO_TEST_CASE(pop_back) {
	Vector<int> a;
	int* ans = new int[1000];
	for (int i = 0; i < 1000; i++) {
		ans[i] = rand();
		a.push_back(ans[i]);
	}
	for (int i = 0; i < 500; i++)
		a.pop_back();
	for (int i = 0; i < 500; i++)
		BOOST_CHECK_EQUAL(ans[i], a[i]);
	delete[] ans;
}

BOOST_AUTO_TEST_CASE(empty_size_capacity) {
	Vector<int> a;
	int c = 1;
	BOOST_CHECK_EQUAL(1, a.is_empty());
	for (int i = 1; i <= 100; i++) {
		if (c <= i)
			c *= 2;
		a.push_back(rand());
		BOOST_CHECK_EQUAL(0, a.is_empty());
		BOOST_CHECK_EQUAL(c, a.capacity());
		BOOST_CHECK_EQUAL(i, a.size());
	}
	for (int i = 99; i <= 1; i--) {
		if (c >= i * 4)
			c /= 2;
		a.pop_back();
		BOOST_CHECK_EQUAL(0, a.is_empty());
		BOOST_CHECK_EQUAL(c, a.capacity());
		BOOST_CHECK_EQUAL(i, a.size());
	}
}

BOOST_AUTO_TEST_CASE(resize_reserve) {
	Vector <int> a;
	int c = 1;
	for (int i = 0; i <= 100; i++) {
		if (c < i)
			c *= 2;
		a.resize(i);
		BOOST_CHECK_EQUAL(c, a.capacity());
		BOOST_CHECK_EQUAL(i, a.size());
	}
	for (int i = 99; i >= 1; i--) {
		if (c >= i * 2)
			c /= 2;
		a.resize(i);
		BOOST_CHECK_EQUAL(c, a.capacity());
		BOOST_CHECK_EQUAL(i, a.size());
	}
}

BOOST_AUTO_TEST_CASE(Test_throws) {
	Vector<int> a;
	BOOST_CHECK_THROW(a.pop_back(), logic_error);
	for (size_t i = 0; i < 10; i++)
		a.push_back(rand());
	BOOST_CHECK_THROW(a[10], out_of_range);
}

BOOST_AUTO_TEST_SUITE_END();


BOOST_AUTO_TEST_SUITE(test_Heap)

BOOST_AUTO_TEST_CASE(Test_throws) {
	THeap<int> h;
	BOOST_CHECK_THROW(h.extract_min(), logic_error);
	BOOST_CHECK_THROW(h.get_min(), logic_error);
	for (size_t i = 0; i < 10; i++)
		h.insert(rand());
	for (size_t i = 0; i < 10; i++)
		h.extract_min();
	BOOST_CHECK_THROW(h.extract_min(), logic_error);
	BOOST_CHECK_THROW(h.get_min(), logic_error);
}

BOOST_AUTO_TEST_CASE(extractmin_getmin) {
	THeap<int> h;
	TestHeap th;
	for (int i = 0; i < 1000; i++) {
		int x = rand() % 20; //���������� ������ ��������� �����������, ����� ���� ��������
		h.insert(x);
		th.insert(x);
		BOOST_CHECK_EQUAL(h.get_min(), th.get_min());
	}
	for (int i = 0; i < 1000; i++) 
		BOOST_CHECK_EQUAL(h.extract_min(), th.extract_min());
}

BOOST_AUTO_TEST_CASE(extractmin_getmin_empty) {
	THeap<int> h;
	TestHeap th;
	for (int i = 0; i < 1000; i++) {
		int type = rand() % 3;
		if (type == 0) {
			int x = rand() % 20;
			h.insert(x);
			th.insert(x);
		}
		if (type == 1) {
			if (!th.is_empty())
				BOOST_CHECK_EQUAL(h.get_min(), th.get_min());
		}
		if (type == 2) {
			if (!th.is_empty())
				BOOST_CHECK_EQUAL(h.extract_min(), th.extract_min());
		}
		BOOST_CHECK_EQUAL(h.is_empty(), th.is_empty());
	}
}

BOOST_AUTO_TEST_CASE(time_test) {
	THeap<int> h;
	int m = 1000000;
	int x;
	vector <int> r_type(m), rnd(m);
	for (int i = 0; i < m; i++) {
		r_type[i] = rand() % 3;
		rnd[i] = rand() % 1000;
	}
	start = clock();
	for (int i = 0; i < 10000; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
			x = h.get_min();
		if (type == 2)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "N = 10000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";

	start = clock();
	for (int i = 0; i < 100000; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
				x = h.get_min();
		if (type == 2)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "N = 100000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";

	start = clock();
	for (int i = 0; i < 1000000; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
				x = h.get_min();
		if (type == 2)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "N = 1000000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";
}

void test_optimaze(int K) {
	THeap<int> h;
	int m = 1000000;
	int x;
	vector <int> r_type(m), rnd(m);
	int kInsert = 0;
	for (int i = 0; i < K; i++) {
		r_type[i] = 0;
		rnd[i] = rand() % 1000;
	}
	for (int i = K; i < m; i++) {
		r_type[i] = 1;
		rnd[i] = rand() % 1000;
	}
	start = clock();
	for (int i = 0; i < m; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "N = 1000000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";
	h.optimaze(kInsert, m - kInsert);
	start = clock();
	for (int i = 0; i < m; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "optimaze, kInsert = "<< K << " N = 1000000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";
}

BOOST_AUTO_TEST_CASE(optimaze) {
	test_optimaze(500000);
	test_optimaze(800000);
	test_optimaze(900000);
	test_optimaze(990000);
	test_optimaze(999000);
	test_optimaze(999900);
}

BOOST_AUTO_TEST_CASE(constructor) {
	vector <int> a(1000);
	for (int i = 0; i < 1000; i++) {
		a[i] = rand() % 100;
	}
	THeap <int> h(a.begin(), a.end());
	TestHeap th(a);
	for (int i = 0; i < 1000; i++)
		BOOST_CHECK_EQUAL(h.extract_min(), th.extract_min());
}

BOOST_AUTO_TEST_CASE(constructor_time) {
	vector <int> a(100000);
	for (int i = 0; i < 100000; i++) {
		a[i] = rand() % 100;
	}
	start = clock();
	THeap <int> h2;
	for (vector <int>::iterator it = a.begin(); it != a.end(); it++)
		h2.insert(*it);
	end = clock();
	cout << "usial_time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";
	start = clock();
	THeap <int> h(a.begin(), a.end());
	end = clock();
	cout << "constructor_time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";
}

BOOST_AUTO_TEST_SUITE_END();


BOOST_AUTO_TEST_SUITE(test_BinHeap)


BOOST_AUTO_TEST_CASE(Test_throws) {
	BinHeap<int> h;
	BOOST_CHECK_THROW(h.extract_min(), logic_error);
	BOOST_CHECK_THROW(h.get_min(), logic_error);
	for (size_t i = 0; i < 5; i++)
		h.insert(rand() % 10);
	for (size_t i = 0; i < 5; i++)
		h.extract_min();
	BOOST_CHECK_THROW(h.extract_min(), logic_error);
	BOOST_CHECK_THROW(h.get_min(), logic_error);
}

BOOST_AUTO_TEST_CASE(extractmin_getmin) {
	BinHeap<int> h;
	TestHeap th;
	for (int i = 0; i < 1000; i++) {
		int x = rand() % 20; //���������� ������ ��������� �����������, ����� ���� ��������
		h.insert(x);
		th.insert(x);
		BOOST_CHECK_EQUAL(h.get_min(), th.get_min());
	}
	for (int i = 0; i < 1000; i++)
		BOOST_CHECK_EQUAL(h.extract_min(), th.extract_min());
}

BOOST_AUTO_TEST_CASE(extractmin_merge) {
	BinHeap<int> h, addh;
	TestHeap th, addth;
	for (int i = 0; i < 10; i++) {
		//cout << i << "\n";
		int adds = rand() % 50;
		for (int i = 0; i < adds; i++) {
			int x = rand() % 100;
			addh.insert(x);
			addth.insert(x);
		}
		h.merge(addh);
		th.merge(addth);
		for (int i = 0; i < 50; i++) {
			int type = rand() % 2;
			if (type == 0) {
				int x = rand() % 100;
				h.insert(x);
				th.insert(x);
				BOOST_CHECK_EQUAL(h.get_min(), th.get_min());
			}
			else {
				if (!h.is_empty())
					BOOST_CHECK_EQUAL(h.extract_min(), th.extract_min());
			}
			BOOST_CHECK_EQUAL(h.is_empty(), th.is_empty());
		}
	}
}

BOOST_AUTO_TEST_CASE(extractmin_getmin_empty) {
	BinHeap<int> h;
	TestHeap th;
	for (int i = 0; i < 1000; i++) {
		int type = rand() % 3;
		if (type == 0) {
			int x = rand() % 20;
			h.insert(x);
			th.insert(x);
		}
		if (type == 1) {
			if (!th.is_empty())
				BOOST_CHECK_EQUAL(h.get_min(), th.get_min());
		}
		if (type == 2) {
			if (!th.is_empty())
				BOOST_CHECK_EQUAL(h.extract_min(), th.extract_min());
		}
		BOOST_CHECK_EQUAL(h.is_empty(), th.is_empty());
	}
}

BOOST_AUTO_TEST_CASE(time_test) {
	cout << "BinHeap" << "\n";
	BinHeap<int> h;
	int m = 10000000;
	int x;
	vector <int> r_type(m), rnd(m);
	for (int i = 0; i < m; i++) {
		r_type[i] = rand() % 3;
		rnd[i] = rand() % 1000;
	}
	start = clock();
	for (int i = 0; i < 10000; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
				x = h.get_min();
		if (type == 2)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "N = 10000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";

	start = clock();
	for (int i = 0; i < 100000; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
				x = h.get_min();
		if (type == 2)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "N = 100000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";

	start = clock();
	for (int i = 0; i < 1000000; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
				x = h.get_min();
		if (type == 2)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "N = 1000000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";
	start = clock();
	for (int i = 0; i < 10000000; i++) {
		int type = r_type[i];
		if (type == 0) {
			x = rnd[i];
			h.insert(x);
		}
		if (type == 1)
			if (!h.is_empty())
				x = h.get_min();
		if (type == 2)
			if (!h.is_empty())
				x = h.extract_min();
	}
	end = clock();
	cout << "N = 10000000, time = " << (end - start) / (double)CLOCKS_PER_SEC * 1000 << "ms\n";
	int y;
	std::cin >> y;
}


BOOST_AUTO_TEST_SUITE_END();