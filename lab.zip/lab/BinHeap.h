#pragma once
#include "Vector.H"
#include<stdexcept>

using std::logic_error;

template <class Key>
class BinHeap {
private:
	class TNode;
	TNode* tree = nullptr;
	TNode* minKey = nullptr;
	void delete_all(TNode*& v);
	void recalcmin();
	void swap(TNode*& a, TNode*&b);
public:
	BinHeap(Key x);
	BinHeap() = default;
	BinHeap(BinHeap &otherHeap);
	void insert(Key key);
	bool is_empty();
	Key extract_min();
	Key get_min();
	void merge(BinHeap &otherHeap);
	~BinHeap();
};

template <class Key>
class BinHeap<Key>::TNode {
public:
	Key value;
	int rg = 0;
	TNode *parent = nullptr, *leftSon = nullptr, *rightSon = nullptr, *next = nullptr, *prev = nullptr;
	TNode(Key val = 0) : value(val) {}
	TNode(const TNode& t) {
		*this = t;
	}

	TNode operator=(TNode t) {
		if (this == &t)
			return *this;
		leftSon = t.leftSon;
		rightSon = t.leftSon;
		parent = t.parent;
		next = t.next;
		prev = t.prev;
		value = t.value;
		return *this;
	}

	void add_son(TNode*& v) {
		v->parent = this;
		if (leftSon == nullptr) {
			leftSon = v;
			rightSon = v;
			v->next = nullptr;
			v->prev = nullptr;
		}
		else {
			v->prev = rightSon;
			v->next = nullptr;
			rightSon->next = v;
			rightSon = rightSon->next;
		}
	}
};

template <class Key>
void BinHeap<Key>::swap(TNode*& a, TNode*& b) {
	TNode* tmp = b;
	b = a;
	a = tmp;
}

template <class Key>
BinHeap<Key>::BinHeap(BinHeap &h) {
	tree = h.tree;
	minKey = h.minKey;
}

template <class Key>
BinHeap<Key>::~BinHeap() {
	delete_all(tree);
}

template <class Key>
void BinHeap<Key>::delete_all(TNode*& v) {
	if (v == nullptr)
		return;
	if (v->leftSon) {
		TNode* cur = v->leftSon;
		v->leftSon = nullptr;
		v->rightSon = nullptr;
		delete_all(cur);
	}
	if (v->next) {
		TNode* cur = v->next;
		v->next = nullptr;
		v->prev = nullptr;
		delete_all(cur);
	}
	v->parent = nullptr;
	delete v;
}

template <class Key>
bool BinHeap<Key>::is_empty() {
	return tree == nullptr;
}

template <class Key>
void BinHeap<Key>::merge(BinHeap<Key> &H) {
	if (is_empty()) {
		*this = H;
		H.tree = nullptr;
		H.minKey = nullptr;
		return;
	}
	if (H.is_empty())
		return;
	TNode* v1 = tree;
	TNode* v2 = H.tree;
	if (tree->rg > v2->rg)
		tree = v2, swap(v1, v2);
	while (v2 !=  nullptr) {
		while ((v1->next != nullptr) && (v1->next->rg < v2->rg))
			v1 = v1->next;
		TNode* newv2 = v2->next;
		TNode* tmp = v1->next;
		v1->next = v2;
		v2->prev = v1;
		v2->next = tmp;
		if (tmp != nullptr)
			tmp->prev = v2;
		v2 = newv2;
		v1 = v1->next;
	}
	
	v1 = tree;
	while (v1 != nullptr) {
		v2 = v1->next;
		TNode* prev = v1->prev;
		if ((v2 != nullptr) && (v2->rg == v1->rg)) {
			TNode* next = v2->next;
			if (v1->value > v2->value)
				swap(v1, v2);
			v1->add_son(v2);
			v1->prev = prev;
			v1->next = next;
			v1->rg++;
			if (prev != nullptr)
				prev->next = v1;
			else
				tree = v1;
			if (next != nullptr)
				next->prev = v1;
		}
		else
			v1 = v2;
	}
	recalcmin();
	H.minKey = nullptr;
	H.tree = nullptr;
}

template <class Key>
void BinHeap<Key>::recalcmin() {
	minKey = tree;
	TNode* v = minKey;
	while (v != nullptr) {
		if (minKey->value > v->value)
			minKey = v;
		v = v->next;
	}
}

template <class Key>
BinHeap<Key>::BinHeap(Key x) {
	TNode* v = new TNode(x);
	tree  = v;
	minKey = v;
}

template <class Key>
void BinHeap<Key>::insert(Key key) {
	BinHeap H(key);
	merge(H);
}

template <class Key>
Key BinHeap<Key>::extract_min() {
	if (is_empty())
		throw logic_error("Heap is empty");
	Key ans = minKey->value;
	TNode* next = minKey->next;
	TNode* prev = minKey->prev;
	if (prev != nullptr)
		prev->next = next;
	else
		tree = next;
	if (next != nullptr)
		next->prev = prev;
	BinHeap<Key> H;
	H.tree = minKey->leftSon;
	delete minKey;
	H.recalcmin();
	TNode* v = H.tree;
	while (v != nullptr)
		v->parent = nullptr, v = v->next;
	merge(H);
	recalcmin();
	return ans;
}

template <class Key>
Key BinHeap<Key>::get_min() {
	if (is_empty())
		throw logic_error("Heap is empty");
	return minKey->value;
}

